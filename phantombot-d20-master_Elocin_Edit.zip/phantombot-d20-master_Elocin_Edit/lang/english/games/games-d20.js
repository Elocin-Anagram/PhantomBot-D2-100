$.lang.register('d20.no_last', '$1, the D20 has not been rolled yet!');
$.lang.register('d20.last', '$1, the last D20 roll was $2 by $3');
$.lang.register('d20.response', '$1, the D20 rolled a $2');
