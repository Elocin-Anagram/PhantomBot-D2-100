$.lang.register('d8.no_last', '$1, the D8 has not been rolled yet!');
$.lang.register('d8.last', '$1, the last D8 roll was $2 by $3');
$.lang.register('d8.response', '$1, the D8 rolled a $2');