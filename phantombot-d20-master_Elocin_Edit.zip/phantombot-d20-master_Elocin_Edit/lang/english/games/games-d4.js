$.lang.register('d4.no_last', '$1, the D4 has not been rolled yet!');
$.lang.register('d4.last', '$1, the last D4 roll was $2 by $3');
$.lang.register('d4.response', '$1, the D4 rolled a $2');