$.lang.register('d2.no_last', '$1, the D2 has not been rolled yet!');
$.lang.register('d2.last', '$1, the last D2 roll was $2 by $3');
$.lang.register('d2.response', '$1, the D2 rolled a $2');