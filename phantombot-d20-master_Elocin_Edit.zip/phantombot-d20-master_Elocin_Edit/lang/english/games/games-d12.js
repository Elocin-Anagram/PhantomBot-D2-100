$.lang.register('d10.no_last', '$1, the D12 has not been rolled yet!');
$.lang.register('d12.last', '$1, the last D12 roll was $2 by $3');
$.lang.register('d12.response', '$1, the D12 rolled a $2');