$.lang.register('d10.no_last', '$1, the D100 has not been rolled yet!');
$.lang.register('d100.last', '$1, the last D100 roll was $2 by $3');
$.lang.register('d100.response', '$1, the D100 rolled a $2');