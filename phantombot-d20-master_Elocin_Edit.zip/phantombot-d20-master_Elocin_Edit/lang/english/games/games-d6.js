$.lang.register('d6.no_last', '$1, the D6 has not been rolled yet!');
$.lang.register('d6.last', '$1, the last D6 roll was $2 by $3');
$.lang.register('d6.response', '$1, the D6 rolled a $2');