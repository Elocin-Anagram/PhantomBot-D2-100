/**
 * d100.js
 *
 * Literally just rolls a d100
 */
(function() {
  var lastRoll = 0;
  var lastRoller = null;

    /**
     * @event command
     */
    $.bind('command', function(event) {
        var sender = event.getSender().toLowerCase(),
            command = event.getCommand(),
            args = event.getArgs(),
            random;

        var ranked_sender = $.resolveRank(sender);

        /**
         * @commandpath d100 ?last - Roll a D100, or retrieve the last result
         */
        if (command.equalsIgnoreCase('d100')) {
            if (args[0] && args[0] == 'last') {
                if (!lastRoll) {
                  $.say($.lang.get('d100.no_last', ranked_sender));
                } else {
                  if (lastRoller == sender) {
                    $.say($.lang.get('d100.last', ranked_sender, lastRoll, 'you'));
                  } else {
                    $.say($.lang.get('d100.last', ranked_sender, lastRoll, lastRoller));
                  }
                }
                return
            }

            random = $.randRange(1, 100);

            $.say($.lang.get('d100.response', ranked_sender, random));
            lastRoll = random;
            lastRoller = sender;
        }
    });

    /**
     * @event initReady
     */
    $.bind('initReady', function() {
        if ($.bot.isModuleEnabled('./games/d100.js')) {
            $.registerChatCommand('./games/d100.js', 'd100', 7);
        }
    });
})();